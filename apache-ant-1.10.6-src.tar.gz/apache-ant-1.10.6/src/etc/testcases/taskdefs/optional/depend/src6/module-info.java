module dummy {
    requires java.base;
    exports org.dummy;
}
